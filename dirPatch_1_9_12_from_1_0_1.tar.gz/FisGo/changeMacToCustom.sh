#!/bin/sh
ifconfig eth0 hw ether 
 

